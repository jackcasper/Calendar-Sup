import React, { useState } from 'react';
import { Calendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';

const localizer = momentLocalizer(moment);

const CalendarComponent = () => {
  const [events, setEvents] = useState([]);
  const [offDays, setOffDays] = useState([]);
  const [startHour, setStartHour] = useState(8);
  const [endHour, setEndHour] = useState(18);
  const [classes, setClasses] = useState([]);
  const [newClass, setNewClass] = useState({
    name: '',
    totalTime: '',
    prerequisite: '',
  });
  const [eventIdCounter, setEventIdCounter] = useState(1);

  const handleSelect = ({ start, end }) => {
    const title = window.prompt('Enter a title for the event:');
    if (title) {
      const newEvent = {
        id: eventIdCounter,
        start,
        end,
        title,
      };
      setEvents([...events, newEvent]);
      setEventIdCounter(eventIdCounter + 1);
    }
  };

  const handleDeleteEvent = (id) => {
    const updatedEvents = events.filter((event) => event.id !== id);
    setEvents(updatedEvents);
  };

  const handleOffDayToggle = (date) => {
    const newOffDays = offDays.includes(date)
      ? offDays.filter((day) => day !== date)
      : [...offDays, date];
    setOffDays(newOffDays);
  };

  const customDayPropGetter = (date) => {
    const isOffDay = offDays.includes(date);
    return {
      className: isOffDay ? 'off-day' : '',
    };
  };

  const handleStartHourChange = (event) => {
    const newStartHour = parseInt(event.target.value);
    setStartHour(newStartHour);
  };

  const handleEndHourChange = (event) => {
    const newEndHour = parseInt(event.target.value);
    setEndHour(newEndHour);
  };

  const handleAddClass = () => {
    const newClassWithId = { ...newClass, id: generateUniqueId() };
    setClasses([...classes, newClassWithId]);

    setNewClass({
      name: '',
      totalTime: '',
      prerequisite: '',
    });
  };

  const handleDeleteClass = (id) => {
    const updatedClasses = classes.filter((cls) => cls.id !== id);
    setClasses(updatedClasses);
  };

  const handleClassChange = (event) => {
    const { name, value } = event.target;
    setNewClass((prevClass) => ({ ...prevClass, [name]: value }));
  };

  const generateSummary = () => {
    const summary = {};
    events.forEach((event) => {
      const date = moment(event.start).format('YYYY-MM-DD');
      const duration = moment(event.end).diff(event.start, 'hours');
      if (summary[date]) {
        summary[date] += duration;
      } else {
        summary[date] = duration;
      }
    });
    return (
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Total Hours</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {Object.entries(summary).map(([date, hours]) => (
            <tr key={date}>
              <td>{date}</td>
              <td>{hours}</td>
              <td>
                <button onClick={() => handleDeleteEvent(date)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  const generateUniqueId = () => {
    return Math.random().toString(36).substr(2, 9);
  };

  const generateLinkToHTML = () => {
    const calendarId = generateUniqueId();
    const linkToHTML = `${window.location.origin}/calendar/${calendarId}`;
    const html = `<a href="${linkToHTML}">View Calendar</a>`;
    return html;
  };

  const handleShareHTML = () => {
    const html = generateLinkToHTML();
    // Implement logic to share the link to the HTML page
    // For example, copy the link to the clipboard or display it in a modal
    console.log(html);
  };

  const generateICalContent = () => {
    let icalContent = `BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//My Calendar//EN\n`;
    events.forEach((event) => {
      const startDate = moment(event.start).format('YYYYMMDDTHHmmss');
      const endDate = moment(event.end).format('YYYYMMDDTHHmmss');
      const summary = event.title;
      icalContent += `BEGIN:VEVENT\nDTSTART:${startDate}\nDTEND:${endDate}\nSUMMARY:${summary}\nEND:VEVENT\n`;
    });
    icalContent += `END:VCALENDAR\n`;
    return icalContent;
  };

  const handleDownloadICal = () => {
    const icalContent = generateICalContent();
    const blob = new Blob([icalContent], { type: 'text/calendar' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'calendar.ics';
    link.click();
  };

  return (
    <div>
      <div>
        <label>Start Hour:</label>
        <input
          type="number"
          value={startHour}
          min={0}
          max={23}
          onChange={handleStartHourChange}
        />
      </div>
      <div>
        <label>End Hour:</label>
        <input
          type="number"
          value={endHour}
          min={0}
          max={23}
          onChange={handleEndHourChange}
        />
      </div>
      <Calendar
        localizer={localizer}
        events={events}
        startAccessor="start"
        endAccessor="end"
        selectable
        onSelectSlot={handleSelect}
        dayPropGetter={customDayPropGetter}
        min={moment().startOf('day').set('hour', startHour)}
        max={moment().startOf('day').set('hour', endHour)}
        style={{ height: 500 }}
      />
      <div>
        <h2>Off Days</h2>
        <ul>
          {offDays.map((date) => (
            <li key={date}>
              {moment(date).format('YYYY-MM-DD')}
              <input
                type="checkbox"
                checked={offDays.includes(date)}
                onChange={() => handleOffDayToggle(date)}
              />
            </li>
          ))}
        </ul>
      </div>
      <div>
        <h2>Add Class</h2>
        <input
          type="text"
          name="name"
          placeholder="Name"
          value={newClass.name}
          onChange={handleClassChange}
        />
        <input
          type="text"
          name="totalTime"
          placeholder="Total Time"
          value={newClass.totalTime}
          onChange={handleClassChange}
        />
        <input
          type="text"
          name="prerequisite"
          placeholder="Prerequisite"
          value={newClass.prerequisite}
          onChange={handleClassChange}
        />
        <button onClick={handleAddClass}>Add Class</button>
      </div>
      <div>
        <h2>Classes</h2>
        <ul>
          {classes.map((cls) => (
            <li key={cls.id}>
              {cls.name} - {cls.totalTime} - {cls.prerequisite}
              <button onClick={() => handleDeleteClass(cls.id)}>Delete</button>
            </li>
          ))}
        </ul>
      </div>
      <div>
        <h2>Summary</h2>
        {generateSummary()}
      </div>
      <div>
        <h2>Share Calendar</h2>
        <button onClick={handleShareHTML}>Share HTML</button>
        <button onClick={handleDownloadICal}>Download iCal</button>
      </div>
    </div>
  );
};

export default CalendarComponent;
