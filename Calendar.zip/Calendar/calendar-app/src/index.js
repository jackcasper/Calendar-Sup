import React from 'react';
import ReactDOM from 'react-dom';
import CalendarComponent from './Calendar';

ReactDOM.render(
  <React.StrictMode>
    <CalendarComponent />
  </React.StrictMode>,
  document.getElementById('root')
);
