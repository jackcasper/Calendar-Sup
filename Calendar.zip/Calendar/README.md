# Calendar
 create a calendar solution allowing the administration to easily organize and setup sessions while removing the hassle of spending a long time to see what would be the best time fit.
